﻿// Il modello di elemento Pagina vuota è documentato all'indirizzo https://go.microsoft.com/fwlink/?LinkId=234238

namespace SoccerAPP
{
    public class Player
    {
        public string Name { get; set; }

        public string Image { get; set; }

        public string Gender { get; set; }

        public string Nationality { get; set; }

        public string Team { get; set; }
    }
}

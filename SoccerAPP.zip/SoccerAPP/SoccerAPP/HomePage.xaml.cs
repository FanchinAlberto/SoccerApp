﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;

// Il modello di elemento Pagina vuota è documentato all'indirizzo https://go.microsoft.com/fwlink/?LinkId=234238

namespace SoccerAPP
{
    /// <summary>
    /// Pagina vuota che può essere usata autonomamente oppure per l'esplorazione all'interno di un frame.
    /// </summary>
    /// 

    public sealed partial class HomePage : Page
    {
        App _AppReference = App.Current as App;
        public List<string> AllTeams { get; set; }
        public HomePage()
        {
            this.InitializeComponent();

            ListViewTeams.ItemsSource = _AppReference.service.AllTeams.OrderBy(q => q).ToList(); 
        }



        private void TeamSelected(object sender, SelectionChangedEventArgs e)
        {
            string value = (sender as ListView).SelectedItem.ToString();
            _AppReference.service.Players = new List<Player>(_AppReference.service.Teams[value]);
            ListViewPlayers.ItemsSource = _AppReference.service.Players;
        }


    }
}

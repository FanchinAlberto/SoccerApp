﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Il modello di elemento Pagina vuota è documentato all'indirizzo https://go.microsoft.com/fwlink/?LinkId=234238

namespace SoccerAPP
{
    /// <summary>
    /// Pagina vuota che può essere usata autonomamente oppure per l'esplorazione all'interno di un frame.
    /// </summary>
    public sealed partial class NewPlayer : Page
    {
        public NewPlayer()
        {
            this.InitializeComponent();
        }
        App _AppReference = App.Current as App;
        private async void SaveData(object sender, RoutedEventArgs e) {
            var photoUrl = PhotoUrl.Text;
            var name = Name.Text;
            var nationality = Nationality.Text;
            var team = Team.Text;
            var gender = Gender.SelectedValue == null ? "":Gender.SelectedValue.ToString();
    

            var titleMessage = "Data not valid";
            string msg = string.IsNullOrWhiteSpace(photoUrl) ? "PhotoUrl" :
                string.IsNullOrWhiteSpace(name) ? "Name" :
                string.IsNullOrWhiteSpace(nationality) ? "Nationality" :
                string.IsNullOrWhiteSpace(team) ? "Team" :
                string.IsNullOrWhiteSpace(gender) ? "Gender" : "";
            if (string.IsNullOrWhiteSpace(msg))
            {
                await new MessageDialog(titleMessage, $"{msg} is empty").ShowAsync();
                return;
            }
            //salvataggio csv

            var players = _AppReference.service.AllPlayers;
            using (var writer = new StreamWriter("players.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(players);
            }
        }
    }
}
